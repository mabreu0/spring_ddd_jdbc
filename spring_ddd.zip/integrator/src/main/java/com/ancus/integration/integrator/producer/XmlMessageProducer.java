package com.ancus.integration.integrator.producer;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;


@Component
public class XmlMessageProducer {

        private RestTemplate restTemplateClient;
        private String url = "http://localhost:8383/api/list/orders";

        public XmlMessageProducer() {
            this.restTemplateClient = new RestTemplate();
        }

        public String retrieveContentCall() {
            //ResponseEntity<Object> response = this.restTemplateClient.getForEntity(url, Object.class);
            String response = this.restTemplateClient.getForObject(url, String.class);

            return response.toString();
        }
}
