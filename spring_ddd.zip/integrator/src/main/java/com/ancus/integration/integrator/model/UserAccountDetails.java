package com.ancus.integration.integrator.model;


/*@XmlRootElement(name = "UserAccountDetails")*/
public class UserAccountDetails {

    private String accountName;
    private String id;
    private String userName;
    private String accountOpenDate;
    private String accountLastTransaction;
    private long accountBalance;

    private String tel1;
    private String tel2;
    private String tel3;

    public String accountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    public String id() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String userName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String accountOpenDate() {
        return accountOpenDate;
    }

    public void setAccountOpenDate(String accountOpenDate) {
        this.accountOpenDate = accountOpenDate;
    }

    public String accountLastTransaction() {
        return accountLastTransaction;
    }

    public void setAccountLastTransaction(String accountLastTransaction) {
        this.accountLastTransaction = accountLastTransaction;
    }

    public long accountBalance() {
        return accountBalance;
    }

    public void setAccountBalance(long accountBalance) {
        this.accountBalance = accountBalance;
    }

    public String tel1() {
        return tel1;
    }

    public void setTel1(String tel1) {
        this.tel1 = tel1;
    }

    public String tel2() {
        return tel2;
    }

    public void setTel2(String tel2) {
        this.tel2 = tel2;
    }

    public String tel3() {
        return tel3;
    }

    public void setTel3(String tel3) {
        this.tel3 = tel3;
    }

    public String address1() {
        return address1;
    }

    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    public String address2() {
        return address2;
    }

    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    private String address1;
    private String address2;

}