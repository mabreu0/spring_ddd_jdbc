package com.ancus.integration.integrator;

import com.ancus.integration.integrator.channel.RestContentChannel;
import com.ancus.integration.integrator.handler.ContentSegmentHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpMethod;
import org.springframework.integration.core.GenericHandler;
import org.springframework.integration.core.MessageSource;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.MessageChannels;
import org.springframework.integration.dsl.Pollers;
import org.springframework.integration.http.dsl.Http;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.MessageHeaders;
import org.springframework.messaging.support.MessageBuilder;

import com.ancus.integration.integrator.producer.XmlMessageProducer;


@SpringBootApplication
public class IntegratorApplication {
	private static final String urlEndpoint = "http://localhost:8383/api/list/orders";

	@Autowired
	ContentSegmentHandler segmentHandler;

	@Autowired
	XmlMessageProducer messageProducer;

    /*
	@Autowired
	RestContentChannel restContentChannel;
	 */

	public static void main(String[] args) {
		SpringApplication.run(IntegratorApplication.class, args);
	}

	@Bean
	MessageSource<String> source() {
		Message<String> orderMessage = MessageBuilder.withPayload(messageProducer.retrieveContentCall()).build();

		MessageSource ms = new MessageSource() {
			@Override
			public Message receive() {

				//return MessageBuilder.fromMessage(orderMessage).setHeader("delete", "removeItems").build();
				return MessageBuilder.fromMessage(orderMessage).build();
			}
		};

		return ms;
	}

	@Bean
	public IntegrationFlow upcaseFlow() {
		return IntegrationFlow.from(source(),
						(configurer)-> configurer.poller(Pollers.fixedDelay(3000))).channel("xmlContentChannel")
				.handle(segmentHandler.handler()).get();
	}
}