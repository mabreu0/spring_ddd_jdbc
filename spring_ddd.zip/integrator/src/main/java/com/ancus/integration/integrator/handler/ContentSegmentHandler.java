package com.ancus.integration.integrator.handler;


import com.ancus.integration.integrator.model.Customer;
import com.ancus.integration.integrator.model.Item;
import com.ancus.integration.integrator.model.Order;
import com.ancus.integration.integrator.model.OrderBuilder;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Marshaller;
import jakarta.xml.bind.Unmarshaller;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.config.EnableIntegration;
import org.springframework.integration.core.GenericHandler;
import org.springframework.messaging.MessageHeaders;

import java.io.StringReader;
import java.io.StringWriter;

import com.ancus.integration.integrator.config.MarshallerConfig;

@Configuration
@EnableIntegration
@Slf4j
public class ContentSegmentHandler {

    @Autowired
    private MarshallerConfig marshaller;

    @Bean
    public GenericHandler<String> handler() {
        GenericHandler<String> genericHandler = new GenericHandler<String>() {
            @Override
            public Object handle(String payload, MessageHeaders headers) {
                String result;
                if(headers.containsValue("removeItems")) {
                    result = removeItems(payload);
                    System.out.println(result);
                } else {
                    System.out.println(payload);
                    result = payload;
                }

                return null;
            }
        };

        return genericHandler;
    }

    private String removeItems(String xmlDocument) {
        StringWriter writer = new StringWriter();
        StringReader reader = new StringReader(xmlDocument);
        JAXBContext context;
        String newStr = null;
        Order order = null;

        try {
           context = JAXBContext.newInstance(Order.class);
           Unmarshaller unmarshaller = context.createUnmarshaller();
           order = (Order) unmarshaller.unmarshal(reader);

           order.setItems(null);

           Marshaller marshaller = context.createMarshaller();

           marshaller.setProperty("jaxb.formatted.output", true);
           marshaller.marshal(order, writer);

        }catch(Exception e) {
            e.printStackTrace();
            log.error(e.getMessage());
        }

        return writer.toString();
    }
}
