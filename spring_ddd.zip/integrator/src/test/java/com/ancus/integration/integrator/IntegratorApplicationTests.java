package com.ancus.integration.integrator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IntegratorApplicationTests {

	void contextLoads() {
	}

}
