package com.transunion.integration.integrator;

import com.transunion.integration.integrator.handler.ContentSegmentHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
//import org.springframework.http.HttpMethod;
import org.springframework.integration.core.MessageSource;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.Pollers;
//import org.springframework.integration.http.dsl.Http;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;

import com.transunion.integration.integrator.producer.XmlMessageProducer;

@SpringBootApplication
public class IntegratorApplication {
	private static final String urlEndpoint = "http://localhost:8383/api/list/orders";

	@Autowired
	ContentSegmentHandler segmentHandler;

	@Autowired
	XmlMessageProducer messageProducer;

	@Value("${com.transunion.cliente}")
	private String client;


	public static void main(String[] args) {
		SpringApplication.run(IntegratorApplication.class, args);
	}

	@Bean
	MessageSource<String> source() {
		//Message<String> orderMessage = MessageBuilder.withPayload(messageProducer.retrieveContentCall()).build();

		Message<String> orderMessage = MessageBuilder.withPayload(messageProducer.getXLSAsString(client)).build();

		MessageSource message  = new MessageSource() {
			@Override
			public Message receive() {
				return MessageBuilder.fromMessage(orderMessage).setHeader("cliente", client).build();
			}
		};
		return message;
	}

	@Bean
	public IntegrationFlow reportingFlow() {
		return IntegrationFlow.from(source(),
						(configurer)-> configurer.poller(Pollers.fixedDelay(9000)))
				.channel("xmlContentChannel")
				.handle(segmentHandler.handler()).get();
	}
}