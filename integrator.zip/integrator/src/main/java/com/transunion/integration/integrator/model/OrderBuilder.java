package com.transunion.integration.integrator.model;

import java.util.ArrayList;
import java.util.List;

public class OrderBuilder {

    private OrderBuilder() {

    }
    public static Order xmlBuilder() {

        List<Item> items = new ArrayList<Item>();
        Customer customer = new Customer();
        Order order = new Order();

        Item item1 = new Item();
        Item item2 = new Item();

        customer.setEmail("email@example.com");
        customer.setName("Braulio Alcantara");
        customer.setPhone("849-383-3221");


        item1.setName("Nick jordan");
        item1.setPrice(4000);
        item1.setQuantity(2);

        item2.setName("PlayStation 4");
        item2.setPrice(12000);
        item2.setQuantity(1);


        items.add(item1);
        items.add(item2);

        order.setCustomer(customer);
        order.setItems(items);

        return order;
    }
}
