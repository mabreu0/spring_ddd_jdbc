package com.transunion.integration.integrator.utils;

import javax.xml.transform.Result;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import lombok.extern.slf4j.Slf4j;
import net.sf.saxon.TransformerFactoryImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.BufferedReader;

@Slf4j
@Component
public class XmlUtil {
    @Autowired
    public ResourceLoader resourceLoader;



    private File assestFile(Resource tentativeFile) {
        File file = null;

        try {
            file = tentativeFile.getFile();
        } catch (IOException ioException) {
            log.error("UNABLE TO INTERSECT FILE FROM CLASSPATH ::: " + tentativeFile.toString());
        }

        return file;
    }

    public File xsltByClient(String client) {

        //final File xmlFile = assestFile(resourceLoader.getResource("classpath:xml/products.xml"));

        File xsltFile = null;

        switch (client) {
            case "BancoScotia":
                xsltFile = assestFile(resourceLoader.getResource("classpath:xslt/scotiabank/scotiabank_mods.xslt"));
                System.out.println(xsltFile.getAbsolutePath());
                //execute scotia code.
                break;

            case "BancoBanesco":
                xsltFile = assestFile(resourceLoader.getResource("classpath:xslt/banesco/banesco_mods.xslt"));
                System.out.println(xsltFile.getAbsolutePath());
                //xsltFile = "banesco_modifications.xslt";
                //execute banesco code.
                break;

            case "BancoPopular":
                xsltFile = assestFile(resourceLoader.getResource("classpath:xslt/popular/popular_mods.xslt"));
                //xsltFile = "popular_modifications.xslt";
                //execute popular code.
                System.out.println(xsltFile.getAbsolutePath());
                break;

            default:
                log.debug("NO VALID CLIENT PROVIDED!");
                //execute default code.
        }

        return xsltFile;
    }

    public String doTransform(String client) {
        File xmlFile = assestFile(resourceLoader.getResource("classpath:xml/example.xml"));

        File xlsCode = xsltByClient(client);
        TransformerFactory transformerFactory;
        Transformer transformer;
        Result result = null;

        try {
            transformerFactory = new TransformerFactoryImpl();
            transformer = transformerFactory.newTransformer(new StreamSource(xlsCode));

            //create the output result
            result = new StreamResult(System.out);

            // transform the XML
            transformer.transform(new StreamSource(xmlFile), result);
        } catch (TransformerException e) {
            log.error("PROBLEMAS APLICANDO LA TRANSFORMACION");
            log.error(e.getMessage());
        }
        //transformer.transform(xmlSource, result);
        return result.toString();
    }

    public String getFileAsString(final File file) {
        //File file = null;
        BufferedReader reader = null;

        if(file == null) {
            throw new RuntimeException("FILE ESTA VACIO*********************");
        }

        String line = null;
        StringBuilder stringBuilder = new StringBuilder();
        String ls = System.getProperty("line.separator");

        try {
            //file = resourceLoader.getResource("classpath:" + filepath).getFile();
            reader = new BufferedReader(new FileReader(file));

            while ((line = reader.readLine()) != null) {
                stringBuilder.append(line);
                stringBuilder.append(ls);
            }

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                reader.close();
            } catch (IOException e) {
                log.error("ERROR CLOSING FILE RESOURCE");
            }
            reader = null;
        }
        return stringBuilder.toString();
    }
}