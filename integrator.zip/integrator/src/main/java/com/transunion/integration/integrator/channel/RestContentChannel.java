package com.transunion.integration.integrator.channel;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.config.EnableIntegration;
import org.springframework.integration.dsl.MessageChannels;
import org.springframework.messaging.MessageChannel;

@Configuration
@EnableIntegration
public class RestContentChannel {

    @Bean
    public MessageChannel xmlContentChannel() {
        return MessageChannels.direct().get();
    }

    @Bean
    public MessageChannel userDetailsChannel() {
        return MessageChannels.direct().get();
    }

    @Bean
    public MessageChannel orderItemsDetails() {
        return MessageChannels.direct().get();
    }
}
