package com.transunion.integration.integrator.model;

public class AbstractCustomer {
}
