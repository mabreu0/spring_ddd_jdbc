package com.transunion.integration.integrator.router;


import org.springframework.context.annotation.Bean;
import org.springframework.integration.annotation.Router;
import org.springframework.integration.config.EnableIntegration;
import org.springframework.integration.router.HeaderValueRouter;
import org.springframework.integration.router.MessageRouter;

@EnableIntegration
public class HeaderBasedRouter {

    @Router(inputChannel = "xmlContentChannel")
    @Bean
    public MessageRouter headerValueRouter() {
        HeaderValueRouter router = new HeaderValueRouter("itemsDetails");
        router.setChannelMapping("headerValue1", "channel1");
        router.setChannelMapping("headerValue2", "channel2");

        return router;
    }
}
