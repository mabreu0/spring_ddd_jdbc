package com.transunion.integration.integrator.producer;

import com.transunion.integration.integrator.utils.XmlUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import java.io.File;

@Component
public class XmlMessageProducer {

    @Autowired
    XmlUtil xmlUtil;

   private RestTemplate restTemplateClient;
   private String url = "http://localhost:8383/api/list/orders";

   public XmlMessageProducer() {
        this.restTemplateClient = new RestTemplate();
   }

   public String retrieveContentCall() {
        String response = this.restTemplateClient.getForObject(url, String.class);

        return response.toString();
   }

   public String getXLSAsString(String client) {
      File xlsFileContent = xmlUtil.xsltByClient(client);
      return xmlUtil.getFileAsString(xlsFileContent);
   }
}
