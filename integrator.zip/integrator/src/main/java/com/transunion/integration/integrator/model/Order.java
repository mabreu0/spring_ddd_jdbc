package com.transunion.integration.integrator.model;

import jakarta.xml.bind.annotation.*;
import jakarta.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

import com.transunion.integration.integrator.utils.LocalDateAdapter;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@XmlRootElement(name = "order")
@XmlAccessorType(XmlAccessType.FIELD)
public class Order {

    @XmlElement(name = "customer")
    public Customer customer;

    @XmlElementWrapper(name = "items")
    @XmlElement(name = "item")
    public List<Item> items;

    @XmlElement(name = "total")
    public double total;

    @XmlElement(name = "date")
    @XmlJavaTypeAdapter(LocalDateAdapter.class)
    public LocalDate date;

    // getters and setters

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

}
