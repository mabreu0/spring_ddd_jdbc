package com.transunion.integration.integrator.config;

import com.transunion.integration.integrator.model.Customer;
import com.transunion.integration.integrator.model.Item;
import com.transunion.integration.integrator.model.Order;
import jakarta.xml.bind.Marshaller;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

import java.util.HashMap;

@Configuration
public class MarshallerConfig {
        @Bean
        public Jaxb2Marshaller jaxb2Marshaller() {
            Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
            marshaller.setClassesToBeBound(new Class[]{
                    //all the classes the context needs to know about
                    Customer.class,
                    Order.class,
                    Item.class
            });
            // marshaller.setContextPath(<jaxb.context-file>)
            // marshaller.setPackagesToScan({"com.foo", "com.baz", "com.bar"});

            marshaller.setMarshallerProperties(new HashMap<String, Object>() {{
                put(Marshaller.JAXB_FORMATTED_OUTPUT, true);
                // set more properties here...
            }});

            return marshaller;
        }

}
