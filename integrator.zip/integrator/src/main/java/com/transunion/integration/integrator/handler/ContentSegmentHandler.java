package com.transunion.integration.integrator.handler;

import com.transunion.integration.integrator.producer.XmlMessageProducer;
import com.transunion.integration.integrator.utils.XmlUtil;
import org.springframework.integration.core.GenericHandler;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.config.EnableIntegration;
import org.springframework.messaging.MessageHeaders;


@Configuration
@EnableIntegration
@Slf4j
public class ContentSegmentHandler {

    @Autowired
    private XmlMessageProducer producer;

    @Autowired
    private XmlUtil xmlUtil;

    @Bean
    public GenericHandler<String> handler() {
        GenericHandler<String> genericHandler = new GenericHandler<String>() {
            @Override
            public Object handle(String payload, MessageHeaders headers) {
                String result;

                if(headers.containsValue("BancoPopular")) {
                    result = xmlUtil.doTransform("BancoPopular");
                    System.out.println("\n");
                }

                if(headers.containsValue("BancoBanesco")) {
                    //result = producer.pickXSLByClient("banesco");
                    //result = producer.getXLSAsString("BancoBanesco");
                    result = xmlUtil.doTransform("BancoBanesco");
                    System.out.println("\n");
                }

                if(headers.containsValue("BancoScotia")) {
                    //result = producer.getXLSAsString("BancoScotia");
                    result = xmlUtil.doTransform("BancoScotia");
                    System.out.println("\n");
                }

                return null;
            }
        };

        return genericHandler;
    }
}