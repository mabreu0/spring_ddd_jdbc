package com.example.proxy.httpclients.config.async;

import java.util.HashMap;
import java.time.Duration;
import java.util.concurrent.Executor;

import com.example.proxy.model.report.GenericReport;
import com.example.proxy.model.Individual;
import com.example.proxy.model.contact.DirTel;
import com.example.proxy.model.contact.PhoneAddress;
import com.example.proxy.model.inquiry.Inquiry;
import org.springframework.web.client.RestTemplate;
import org.springframework.context.annotation.Bean;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import com.example.proxy.model.inquiry.InquiriesSegment;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import javax.xml.bind.Marshaller;

@EnableAsync
@Configuration
public class ClientConfig {

    @Value("${com.transunion.gateway.endpoint}")
    private String gatewayURL;

    @Bean
    RestTemplate proxyRestClient(RestTemplateBuilder builder) {
        return builder.setReadTimeout(Duration.ofSeconds(3))
                .rootUri(gatewayURL)
                .build();
    }

    @Bean
    Executor proxyTaskExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();

        executor.setCorePoolSize(5);
        executor.setMaxPoolSize(5);
        executor.setQueueCapacity(10);

        executor.setThreadNamePrefix("ReportingSegment-");
        executor.initialize();

        return executor;
    }

    @Bean
    public Jaxb2Marshaller jaxb2Marshaller() {
        Jaxb2Marshaller marshaller = new Jaxb2Marshaller();

        marshaller.setClassesToBeBound(
                GenericReport.class,
                Individual.class,
                PhoneAddress.class,
                DirTel.class,
                InquiriesSegment.class,
                Inquiry.class
        );

        marshaller.setMarshallerProperties(new HashMap<String, Object>() {{
            put(javax.xml.bind.Marshaller.JAXB_FORMATTED_OUTPUT, true);
            put(Marshaller.JAXB_FRAGMENT, true);
        }});

        return marshaller;
    }
}