package com.example.proxy.httpclients;

import com.example.proxy.httpclients.config.ClientEndpointsConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class PhoneClient {

    @Autowired
    ClientEndpointsConfig endpointsConfig;

    public String getPhoneContent() {
        // Create a RestTemplate instance
        RestTemplate restTemplate = new RestTemplate();

        // Set the URL of the endpoint you want to consume
        // Send the request and retrieve the response
        ResponseEntity<String> responseEntity = restTemplate.getForEntity(endpointsConfig.getIndividualURL(), String.class);

        // Print the status code of the response
        System.out.println("Response Status: " + responseEntity.getStatusCode());

        // Get the response body as a String
        String responseBody = responseEntity.getBody();

        // Print the response body
        System.out.println("Response Body: " + responseBody);

        return responseBody;
    }
}
