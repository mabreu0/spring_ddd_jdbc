package com.example.proxy.utils;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.IOException;

@Component
@Slf4j
public class XMLUtils {

    @Autowired
    public ResourceLoader resourceLoader;

    public File assestFile(Resource tentativeFile) {
        File file = null;

        try {
            file = tentativeFile.getFile();
        } catch (IOException ioException) {
            log.error("UNABLE TO INTERSECT FILE FROM CLASSPATH ::: " + tentativeFile.toString());
        }

        return file;
    }

    public File xsltByClient(String client) {

        //final File xmlFile = assestFile(resourceLoader.getResource("classpath:xml/products.xml"));

        File xsltFile = null;

        switch (client) {
            case "BancoScotia":
                xsltFile = assestFile(resourceLoader.getResource("classpath:xslt/scotiabank/scotiabank_mods.xslt"));
                break;

            case "BancoBanesco":
                xsltFile = assestFile(resourceLoader.getResource("classpath:xslt/banesco/banesco_mods.xslt"));
                break;

            case "BancoPopular":
                xsltFile = assestFile(resourceLoader.getResource("classpath:xslt/popular/popular_mods.xslt"));
                break;

            default:
                log.debug("NO VALID CLIENT PROVIDED!");
                //execute default code.
        }

        return xsltFile;
    }
}
