package com.example.proxy.utils;

import com.example.proxy.model.Segment;

import java.util.Comparator;

public class SegmentSorter implements Comparator<Segment> {

    @Override
    public int compare(Segment segment1, Segment segment2) {
        if(segment1.hasWeight() > segment2.hasWeight()) {
            return 1;
        } else if(segment1.hasWeight() < segment2.hasWeight()) {
            return -1;
        }
        return 0;
    }
}