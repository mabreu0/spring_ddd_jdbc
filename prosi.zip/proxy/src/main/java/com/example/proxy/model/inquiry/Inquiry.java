package com.example.proxy.model.inquiry;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.Getter;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@XmlAccessorType(XmlAccessType.FIELD)
public class Inquiry {
    @XmlElement(name ="FechaIndagacion")
    private String fechaIndagacion;

    @XmlElement(name = "Suscriptor")
    private String suscriptor;

    @XmlElement(name = "Hora")
    private String hora;

    @XmlElement(name = "Tipo")
    private String tipo;
}