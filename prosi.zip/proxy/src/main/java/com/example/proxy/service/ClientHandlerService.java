package com.example.proxy.service;

import com.example.proxy.utils.XMLUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.File;

@Service
@Slf4j
public class ClientHandlerService {

    @Autowired
    XMLUtils xmlUtils;
    public File xsltByClient(String client) {
        File xsltFile = null;

        switch (client) {
            case "BancoScotia":
                xsltFile = xmlUtils.assestFile(xmlUtils.resourceLoader.getResource("classpath:xslt/scotiabank/scotiabank_mods.xslt"));
                break;

            case "BancoBanesco":
                xsltFile = xmlUtils.assestFile(xmlUtils.resourceLoader.getResource("classpath:xslt/banesco/banesco_mods.xslt"));
                break;

            case "BancoPopular":
                xsltFile = xmlUtils.assestFile(xmlUtils.resourceLoader.getResource("classpath:xslt/popular/popular_mods.xslt"));
                break;

            default:
                log.debug("NO VALID CLIENT PROVIDED!");
                //execute default code.
        }

        return xsltFile;
    }



    /*
    public setupClientSettings(String client) {
        String result;
        String xlst;

        if(client.equals("BancoPopular")) {
            xlst = xmlUtil.load("BancoPopular");
            System.out.println("\n");
        }

        //if(headers.containsValue("BancoBanesco")) {
        if(client.equals("BancoBanesco")) {
            //result = producer.pickXSLByClient("banesco");
            //result = producer.getXLSAsString("BancoBanesco");
            result = xmlUtil.doTransform("BancoBanesco");
            System.out.println("\n");
        }

        if(client.equals("BancoScotia")) {
            //result = producer.getXLSAsString("BancoScotia");
            result = xmlUtil.doTransform("BancoScotia");
            System.out.println("\n");
        }

        return null;
    }*/
}