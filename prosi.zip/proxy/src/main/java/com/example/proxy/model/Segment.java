package com.example.proxy.model;

import java.io.Serializable;

public interface Segment extends Serializable {
    public byte hasWeight();
}