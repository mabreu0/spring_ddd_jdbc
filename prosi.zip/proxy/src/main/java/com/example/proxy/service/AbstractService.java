package com.example.proxy.service;

import org.springframework.web.client.RestTemplate;

interface AbstractService {
    String doTransform(String client, String xmlReport);
}