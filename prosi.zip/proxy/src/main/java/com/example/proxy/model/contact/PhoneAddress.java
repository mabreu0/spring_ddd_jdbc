package com.example.proxy.model.contact;

import com.example.proxy.model.Segment;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;

import javax.xml.bind.Marshaller;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@Data
@XmlRootElement(name = "DireccionesTelefonos")
public class PhoneAddress implements Segment  {
    private List<DirTel> dirTelList;

    public List<DirTel> getDirTelList() {
        return dirTelList;
    }

    @XmlElement(name = "DirTel")
    public void setDirTelList(List<DirTel> dirTelList) {
        this.dirTelList = dirTelList;
    }

    @Override
    public byte hasWeight() {
        return 4;
    }
}
