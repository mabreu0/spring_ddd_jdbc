package com.example.proxy.service;

import java.io.StringWriter;
import java.util.List;

import com.example.proxy.model.report.GenericReport;
import lombok.extern.slf4j.Slf4j;
import com.example.proxy.model.Segment;
import org.springframework.stereotype.Service;
import javax.xml.transform.stream.StreamResult;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.beans.factory.annotation.Autowired;

@Slf4j
@Service
public class ReportGenerator {
    @Autowired
    Jaxb2Marshaller jaxb2Marshaller;

    public String xmlToString(Segment segment) {
        StringWriter stringWriter = new StringWriter();
        StreamResult result = new StreamResult(stringWriter);

        jaxb2Marshaller.marshal(segment, result);

        return stringWriter.toString();
    }

    public String xmlToString(GenericReport report) {
        StringWriter stringWriter = new StringWriter();
        StreamResult result = new StreamResult(stringWriter);

        jaxb2Marshaller.marshal(report, result);
        return stringWriter.toString();
    }


    public String generateReport(List<Segment> segments) {
        StringBuilder xml = new StringBuilder();

        for(Segment segment : segments) {
            xml.append(segment);
        }

        return xml.toString();
    }
}
