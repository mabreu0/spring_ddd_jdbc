package com.example.proxy.model;

import lombok.Data;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@Data
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "DatosGenerales")
public class Individual implements Segment {

    @XmlElement(name = "PrimerNombre")
    private String primerNombre;

    @XmlElement(name = "SegundoNombre")
    private String segundoNombre;

    @XmlElement(name = "PrimerApellido")
    private String primerApellido;

    @XmlElement(name = "SegundoApellido")
    private String segundoApellido;

    @XmlElement(name = "CedulaNueva")
    private String cedulaNueva;

    @XmlElement(name = "CedulaVieja")
    private String cedulaVieja;

    @XmlElement(name = "Sexo")
    private String sexo;

    @XmlElement(name = "Pasaporte")
    private String pasaporte;

    @XmlElement(name = "LugarNacimiento")
    private String lugarNacimiento;

    @XmlElement(name = "FechaNacimiento")
    private String fechaNacimiento;

    @XmlElement(name = "EstadoCivil")
    private String estadoCivil;

    @XmlElement(name = "Edad")
    private String edad;

    @XmlElement(name = "Ocupacion")
    private String ocupacion;

    @XmlElement(name = "Categoria")
    private String categoria;

    @XmlElement(name = "Conyugue")
    private String conyugue;

    @XmlElement(name = "CedulaConyugue")
    private String cedulaConyugue;


    @XmlElement(name = "Padre")
    private String padre;

    @XmlElement(name = "Madre")
    private String madre;

    @Override
    public byte hasWeight() {
        return 1;
    }
}
