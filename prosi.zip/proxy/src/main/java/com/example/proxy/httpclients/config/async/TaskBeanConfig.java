package com.example.proxy.httpclients.config.async;


import java.util.concurrent.CompletableFuture;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Slf4j
@Component
public class TaskBeanConfig {

    @Autowired
    RestTemplate restTemplate;
    @Async
    public CompletableFuture<String> retrieveSegmentContent(String segmentUrl) {
        String dataSegment = restTemplate.getForObject(segmentUrl, String.class);

        log.info("000000000000000000000000000000000000000000");
        log.info(Thread.currentThread().getName());
        log.info("000000000000000000000000000000000000000000");

        return CompletableFuture.completedFuture(dataSegment);
    }
}