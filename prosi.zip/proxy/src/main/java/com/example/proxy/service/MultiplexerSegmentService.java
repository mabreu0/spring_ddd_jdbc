package com.example.proxy.service;

import com.example.proxy.httpclients.config.async.TaskBeanConfig;
import com.example.proxy.model.report.GenericReport;
import com.example.proxy.model.Individual;
import com.example.proxy.model.Segment;
import com.example.proxy.model.contact.PhoneAddress;
import com.example.proxy.model.inquiry.InquiriesSegment;
import com.example.proxy.utils.SegmentSorter;
import com.example.proxy.utils.XMLUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.stereotype.Service;

import javax.xml.transform.stream.StreamSource;
import java.io.StringReader;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;


@Slf4j
@Service
public class MultiplexerSegmentService {
    @Autowired
    TaskBeanConfig taskBeanConfig;

    @Autowired
    XMLUtils xmlUtils;

    @Autowired
    Jaxb2Marshaller marshaller;

    @Autowired
    ReportGenerator reportGenerator;
    public List<Segment> dataSegmentsRetreive() {
        CompletableFuture<String> addressAsyncData = null;
        CompletableFuture<String> individualAsyncData = null;
        CompletableFuture<String> inquiryAsyncData = null;

        addressAsyncData = taskBeanConfig.retrieveSegmentContent("http://localhost:8383/api/address/address");
        individualAsyncData = taskBeanConfig.retrieveSegmentContent("http://localhost:8383/api/individual/datosgenerales");
        inquiryAsyncData = taskBeanConfig.retrieveSegmentContent("http://localhost:8383/api/inquiries/inquiries");

        List<Segment> segmentList = null;

        try {
            Individual individual = (Individual)  marshaller.unmarshal(new StreamSource(new StringReader(individualAsyncData.get())));
            PhoneAddress phoneAddress = (PhoneAddress)  marshaller.unmarshal(new StreamSource(new StringReader(addressAsyncData.get())));
            InquiriesSegment inquiriesSegment = (InquiriesSegment) marshaller.unmarshal(new StreamSource(new StringReader(inquiryAsyncData.get())));

            //(segmentList = Arrays.asList(individual, phoneAddress, inquiriesSegment)).sort(new SegmentSorter());

            segmentList = Arrays.asList(individual, phoneAddress, inquiriesSegment);
            segmentList.sort(new SegmentSorter());


        }catch(InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }

        return segmentList;
    }
}