package com.example.proxy.model.contact;

import javax.xml.bind.annotation.XmlElement;

public class DirTel {
    private String fecha;
    private String tipoTel;
    private String tel;
    private String dire;

    public String getFecha() {
        return fecha;
    }

    @XmlElement(name = "Fecha")
    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getTipoTel() {
        return tipoTel;
    }

    @XmlElement(name = "TipoTel")
    public void setTipoTel(String tipoTel) {
        this.tipoTel = tipoTel;
    }

    public String getTel() {
        return tel;
    }

    @XmlElement(name = "Tel")
    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getDire() {
        return dire;
    }

    @XmlElement(name = "Dire")
    public void setDire(String dire) {
        this.dire = dire;
    }
}