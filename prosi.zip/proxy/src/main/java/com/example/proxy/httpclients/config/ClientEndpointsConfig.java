package com.example.proxy.httpclients.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ClientEndpointsConfig {
    protected final String COM_TRANSUNION_REPORT_INDIVIDUAL = "http://localhost:8383/api/individual/datosgenerales";
    protected final String COM_TRANSUNION_REPORT_PHONE = "http://localhost:8383/api/phone/phone";
    protected final String COM_TRANSUNION_REPORT_TRANSACTIONS = "http://localhost:8383/api/transactions/transactions";
    protected final String COM_TRANSUNION_REPORT_ACTIVE_TRANSACTIONS = "http://localhost:8383/api/transactions/active_transactions";
    //COM_TRANSUNION_REPORT_INQUIRIES,
    //COM_TRANSUNION_REPORT_ADDRESS;

    public String getIndividualURL() {
        return COM_TRANSUNION_REPORT_INDIVIDUAL;
    }

    //@Value("${com.transunion.report.individual.${T(java.lang.Enum).valueOf(T(java.lang.String).toUpperCase(name())).name()}}")
    /*
    @Value("${com.transunion.report.individual}")
    public void setIndividualURL(String endPoint) {
        COM_TRANSUNION_REPORT_INDIVIDUAL = endPoint;
    }*/

    public String getPhoneURL() {
        return COM_TRANSUNION_REPORT_PHONE;
    }

    /*
    public void setPhoneURL(String endPoint) {
        COM_TRANSUNION_REPORT_PHONE.setValue(endPoint);
    }*/

    public String getTransactionsURL() {
        return COM_TRANSUNION_REPORT_TRANSACTIONS;
    }

    /*
    public void setTransactionsURL(String endPoint) {
        COM_TRANSUNION_REPORT_TRANSACTIONS.setValue(endPoint);
    }*/

    /*
    // Non-static getter for ENDPOINT_TWO
    public String getEndpointTwo() {
        return ENDPOINT_TWO.getValue();
    }

    // Non-static setter for ENDPOINT_TWO
    public void setEndpointTwo(String value) {
        ENDPOINT_TWO.setValue(value);
    }
     */
}