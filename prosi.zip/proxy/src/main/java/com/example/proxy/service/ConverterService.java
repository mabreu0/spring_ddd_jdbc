package com.example.proxy.service;

import org.springframework.beans.factory.annotation.Autowired;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import org.springframework.stereotype.Service;
import net.sf.saxon.TransformerFactoryImpl;
import com.example.proxy.utils.XMLUtils;
import lombok.extern.slf4j.Slf4j;

import javax.xml.transform.Result;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import java.io.File;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringReader;

@Slf4j
@Service
public class ConverterService implements AbstractService {

    @Autowired
    XMLUtils xmlUtils;

      public String doTransform(String client, String xmlFile) {
        //File xmlFile = xmlUtils.assestFile(xmlUtils.resourceLoader.getResource("classpath:xml/example.xml"));

        File xlsCode = xmlUtils.xsltByClient(client);

        TransformerFactory transformerFactory;
        Transformer transformer;
        Result result = null;

        try {
            transformerFactory = new TransformerFactoryImpl();
            transformer = transformerFactory.newTransformer(new StreamSource(xlsCode));

            result = new StreamResult(System.out);

            StringReader xmlReader = new StringReader(xmlFile);
            transformer.transform(new StreamSource(xmlReader), result);
        } catch (TransformerException e) {
            log.error("PROBLEMAS APLICANDO LA TRANSFORMACION");
            log.error(e.getMessage());
        }
        //transformer.transform(xmlSource, result);
        return result.toString();
    }
}