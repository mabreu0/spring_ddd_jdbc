package com.example.proxy.service;

import org.springframework.beans.factory.annotation.Autowired;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import org.springframework.stereotype.Service;
import net.sf.saxon.TransformerFactoryImpl;
import com.example.proxy.utils.XMLUtils;
import lombok.extern.slf4j.Slf4j;

import javax.xml.transform.Result;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import java.io.File;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringReader;

@Slf4j
@Service
public class ConverterService {

    @Autowired
    XMLUtils xmlUtils;

      public String doTransform(String client, String xmlFile) {
        //File xmlFile = xmlUtils.assestFile(xmlUtils.resourceLoader.getResource("classpath:xml/example.xml"));

        File xlsCode = xmlUtils.xsltByClient(client);

        TransformerFactory transformerFactory;
        Transformer transformer;
        Result result = null;

        try {
            transformerFactory = new TransformerFactoryImpl();
            transformer = transformerFactory.newTransformer(new StreamSource(xlsCode));

            //create the output result
            result = new StreamResult(System.out);

            //transformer.transform(new StreamSource(xmlFile), result);
            //transformer.transform(new StreamSource(new InputStreamReader(xmlFile)), result);
            //transformer.transform(new Reader(xmlFile)), result);
            //otransformer.transform(new StreamSource(new InputStreamReader(xmlFile)), result);

            StringReader xmlReader = new StringReader(xmlFile);
            transformer.transform(new StreamSource(xmlReader), result);
        } catch (TransformerException e) {
            log.error("PROBLEMAS APLICANDO LA TRANSFORMACION");
            log.error(e.getMessage());
        }
        //transformer.transform(xmlSource, result);
        return result.toString();
    }

    /*
    public String getFileAsString(final File file) {
        //File file = null;
        BufferedReader reader = null;

        if(file == null) {
            throw new RuntimeException("FILE ESTA VACIO*********************");
        }

        String line = null;
        StringBuilder stringBuilder = new StringBuilder();
        String ls = System.getProperty("line.separator");

        try {
            //file = resourceLoader.getResource("classpath:" + filepath).getFile();
            reader = new BufferedReader(new FileReader(file));

            while ((line = reader.readLine()) != null) {
                stringBuilder.append(line);
                stringBuilder.append(ls);
            }

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                reader.close();
            } catch (IOException e) {
                log.error("ERROR CLOSING FILE RESOURCE");
            }
            reader = null;
        }
        return stringBuilder.toString();
    }*/
}