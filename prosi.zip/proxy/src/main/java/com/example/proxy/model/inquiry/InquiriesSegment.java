package com.example.proxy.model.inquiry;


import lombok.*;
import java.util.List;
import com.example.proxy.model.Segment;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessorType;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "Indagaciones")
public class InquiriesSegment implements Segment {
    @XmlElement(name="Inquiry")
    private List<Inquiry> inquiries;

    @Override
    public byte hasWeight() {
        return 3;
    }
}