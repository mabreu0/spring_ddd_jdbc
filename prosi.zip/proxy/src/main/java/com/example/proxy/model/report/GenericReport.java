package com.example.proxy.model.report;

import com.example.proxy.model.Individual;
import com.example.proxy.model.Segment;
import com.example.proxy.model.contact.PhoneAddress;
import com.example.proxy.model.inquiry.InquiriesSegment;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@Data
@NoArgsConstructor
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "ReporteCreditodeIndividuo")
public class GenericReport implements Segment {

    @XmlElement(name = "DatosGenerales")
    Individual individual;

    @XmlElement(name = "Indagaciones")
    InquiriesSegment inquiriesSegment;

    @XmlElement(name = "DireccionesTelefonos")
    PhoneAddress phoneAddress;

    public static String getRootField() {
        return "<ReporteCreditodeIndividuo>";
    }

    @Override
    public byte hasWeight() {
        return 0;
    }
}
