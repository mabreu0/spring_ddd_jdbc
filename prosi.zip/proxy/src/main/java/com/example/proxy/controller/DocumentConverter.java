package com.example.proxy.controller;

import com.example.proxy.model.Segment;
import com.example.proxy.service.ReportGenerator;
import lombok.extern.slf4j.Slf4j;
import com.example.proxy.service.ConverterService;
import com.example.proxy.service.MultiplexerSegmentService;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
public class DocumentConverter {

    @Autowired
    private ConverterService converterService;

    @Autowired
    MultiplexerSegmentService segmentService;

    @Autowired
    ReportGenerator reportGenerator;

    @PostMapping("/convert")
    //public void converter(@RequestHeader("client") String client, RequestBody document) {
    public void converter(@RequestHeader("client") String client, @RequestBody String xmlDoc) {
        log.info("################# " + "Entering converter" + "##################");
        converterService.doTransform(client, xmlDoc);
    }

    @PostMapping("/v1/report")
    public void converter(@RequestParam(value="client", required=true) String client) {
        List<Segment> segmentList  = segmentService.dataSegmentsRetreive();

        StringBuffer builder = new StringBuffer();
        builder.append("<ReporteCreditodeIndividuo>");

        builder.append(reportGenerator.xmlToString(segmentList.get(0)));
        builder.append(reportGenerator.xmlToString(segmentList.get(1)));
        builder.append(reportGenerator.xmlToString(segmentList.get(2)));
        //builder.append(reportGenerator.xmlToString(segmentList.get(3)));



        builder.append("</ReporteCreditodeIndividuo>");
        System.out.println(builder.toString());
        System.out.println(converterService.doTransform("BancoPopular", builder.toString()));
    }

    @PostMapping("/transactions")
    public void generateInternationalTransactions(@RequestHeader("client") String client) {

    }
}