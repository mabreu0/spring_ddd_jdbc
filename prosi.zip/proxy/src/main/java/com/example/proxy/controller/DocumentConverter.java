package com.example.proxy.controller;

import com.example.proxy.httpclients.config.ClientEndpointsConfig;
import com.example.proxy.service.ConverterService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
public class DocumentConverter {

    @Autowired
    private ClientEndpointsConfig endpointsConfig;

    @Autowired
    private ConverterService converterService;

    @PostMapping("/convert")
    //public void converter(@RequestHeader("client") String client, RequestBody document) {
    public void converter(@RequestHeader("client") String client, @RequestBody String xmlDoc) {

        converterService.doTransform(client, xmlDoc);

        log.info("################# " + "Entering converter" + "##################");

    }
}